package com.bignerdranch.android.tingle.Model;

import android.content.Context;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * ThingDB is an in-memory database implemented using the singleton pattern and is used to hold a list of things.
 */
public class ThingsDB {
    private static ThingsDB sThingsDB;

    // Fake database
    private List<Thing> mThingsDB;

    // Private constructor to uphold Singleton pattern
    private ThingsDB(Context context) {
        mThingsDB = new ArrayList<Thing>();
        fillThings(); // Test data
    }

    // Public access modifier
    public static ThingsDB get(Context context) {
        if (sThingsDB == null) {
            sThingsDB = new ThingsDB(context);
        }
        return sThingsDB;
    }

    public Iterator<Thing> getAll()
    {
        return mThingsDB.iterator();
    }

    public List<Thing> getThingsDB() { return mThingsDB; }

    public void addThing(Thing thing) { mThingsDB.add(thing);}

    public void removeThing(int position) { mThingsDB.remove(position); }

    public int size() { return mThingsDB.size(); }

    public Thing get(int i) {return mThingsDB.get(i);}

    // Used to generate test data 
    private void fillThings()
    {
        addThing(new Thing("Android Phone", "Desk"));
        addThing(new Thing("Keys", "Kitchen"));
        addThing(new Thing("Book", "Bag"));
        addThing(new Thing("Jacket", "Closet"));
        addThing(new Thing("Notes", "Office"));
    }

}
